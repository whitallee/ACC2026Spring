//Define a class named helloRunner
class helloRunner{
  //Define a method named run. In this program, this
  // method is called from a statement in the main
  // method of the class named hello in the file named
  // hello.java. That statement causes this method to
  // execute and passes control to this method named
  // run.
  void run(){
    //Print the text shown in quotes on the command-
    // line screen.
    System.out.println("Hello World from helloRunner");
    //Nothing more to do here, so control is returned
    //to the main method from which this method was
    //called. There is no requirement for a return
    //statement when nothing is being returned.
  }//end run method
}//end class