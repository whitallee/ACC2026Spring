//Define a class named hello.
class hello{
  //Define a method named main. All java programs
  // must define a method named main. Execution
  // begins and ends in the method named main. When
  // you execute this program with the following
  // command on the command line,
  // java hello
  // the runtime system searches for the file named
  // hello.java containing a method named main
  // and executes that method if it finds it.
  // Otherwise, it throws an error.
  public static void main(String[] args){
    //Call the new operator to create a new object
    // of the class named helloRunner. Once that
    // object comes into existence, use the dot
    // operator to call the method named run belonging
    // to that object. This passes control to the
    // method named run belonging to that object.
    new helloRunner().run();//see comment below
    //When control returns from the run method, in
    //this case there is no more code in the main
    //method so the main method Terminates. When
    //the main method terminates, the program
    //terminates and returns control to the operating
    //system.
  }//end main
}//end class

/*
The statement that begins with new above is a
shorthand version of the following code:
helloRunner obj = new helloRunner();
obj.run();
Both versions produce the same result
*/