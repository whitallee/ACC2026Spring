//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//

/*File KeyEventPostProc01.java
Copyright 2004,R.G.Baldwin
Revised 07/27/04

This program illustrates the use of a
KeyEventPostProcessor in addition to an
alternate KeyEventDispatcher.

This is an upgrade to the program named
KeyEventDispatch01.  This version adds a
KeyEventPostProcessor to process key events after
they have been handled either by the focus owner
or by an alternate KeyEventDispatcher object.

A JFrame object appears on the screen containing
three JTextField objects.  The initial text in
the three JTextField objects is respectively:

Field A
Field B
Field C

Two alternative KeyEventDispatcher objects are
registered on the current KeyboardFocusManager
in the following order:

AlternateDispatcherA
AlternateDispatcherB

In addition a KeyEventPostProcessor object is
registered on the current KeyboardFocusManager.

When a key event occurs, the current
KeyboardFocusManager delivers that event to
AlternateDispatcherA for dispatching.  If the
owner of the focus at that point in time is
Field A, the AlternateDispatcherA object
re-dispatches that event to Field C and returns
false.  That causes keystrokes entered into
Field A to appear in Field C instead.  Returning
false causes the event to be delivered to
AlternateDispatcherB as described below, and also
causes the event to be delivered to the
KeyEventPostProcessor later.

If the owner of the focus at that point in time
is not Field A, the AlternateDispatcherA object
returns false.  This causes the current
KeyboardFocusManager to deliver the event to
AlternateDispatcherB for dispatching.  If the
owner of the focus at that point in time is
Field B, the AlternateDispatcherB object
re-dispatches that event to Field C and returns
false.  That causes keystrokes entered into
Field B to appear in Field C instead.  Returning
false causes the event to be delivered to the
KeyEventPostProcessor later.

If the owner of the focus at that point in time
is not Field B, the AlternateDispatcherB object
returns false.  This causes the current
KeyboardFocusManager to dispatch the event to
the component that owns the focus.  In this
simple program, that would have to be Field C
because it has already been determined that
neither Field A nor Field B own the focus.

That causes keystrokes entered into Field C to
appear in Field C as is normally the case.

Thus, all keystrokes entered into any of the
three fields in the GUI will appear in field C.

In addition, after the event has been dispatched
to the focus owner or delivered to the alternate
KeyEventDispatcher object, the
KeyboardFocusManager will deliver the event to
the KeyEventPostProcessor object for final
processing.  The KeyEventPostProcessor determines
and displays the character that was entered into
the text field and the type of the event.  Three
types of event are possible:

The "key pressed" event.
The "key released" event.
The "key typed" event.

The character and the type of the event are
displayed on the screen as each event is
processed by the KeyEventPostProcessor.  Note
that entering a single character into a text
field causes all three of the event types listed
above to be fired.  The screen output produced
by entering the characters a, b, and c into
fields A, B, and C respectively is shown below.

a keyPressed
a keyTyped
a keyReleased
b keyPressed
b keyTyped
b keyReleased
c keyPressed
c keyTyped
c keyReleased

Note that the KeyEventPostProcessor returns true,
but in this program, it doesn't matter whether
the return value is true or false.  This is
because this program only has one
KeyEventPostProcessor object registered on the
KeyboardFocusManager.  If a KeyEventPostProcessor
object returns false, then the KeyEvent is passed
to the next KeyEventPostProcessor in the chain,
ending with the current KeyboardFocusManager. If
true, the KeyEvent is assumed to have been fully
handled (although this need not be the case), and
the AWT will take no further action with regard
to the KeyEvent.

Tested using J2SE 1.4.2 under WinXP.
************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class KeyEventPostProc01{
  public static void main(String[] args){
    new GUI();
  }//end main
}//end class KeyEventPostProc01
//=============================================//

class GUI extends JFrame{
  JTextField fieldA =
                    new JTextField("Field A",12);
  JTextField fieldB =
                    new JTextField("Field B",12);
  JTextField fieldC =
                    new JTextField("Field C",12);

  KeyboardFocusManager manager;

  GUI(){//constructor
    getContentPane().setLayout(new FlowLayout());
    getContentPane().add(fieldA);
    getContentPane().add(fieldB);
    getContentPane().add(fieldC);

    setSize(390,100);
    setTitle("Copyright 2004, R.G. Baldwin");
    setDefaultCloseOperation(
                           JFrame.EXIT_ON_CLOSE);
    setVisible(true);
    manager = KeyboardFocusManager.
                getCurrentKeyboardFocusManager();

    manager.addKeyEventDispatcher(
                        new AlternateDispatcherA(
                         fieldA,fieldC,manager));
    manager.addKeyEventDispatcher(
                        new AlternateDispatcherB(
                         fieldB,fieldC,manager));
    manager.addKeyEventPostProcessor(
                            new PostProcessor());

  }//end constructor
}//end class GUI
//=============================================//

class AlternateDispatcherA
                   implements KeyEventDispatcher{
  JTextField fieldA;
  JTextField fieldC;
  KeyboardFocusManager manager;

  //Constructor
  AlternateDispatcherA(
                   JTextField fieldA,
                   JTextField fieldC,
                   KeyboardFocusManager manager){
    this.fieldA = fieldA;
    this.fieldC = fieldC;
    this.manager = manager;
  }//end constructor

  public boolean dispatchKeyEvent(KeyEvent e){
    if(e.getSource() == fieldA){
      manager.redispatchEvent(fieldC,e);
    }//end if
    return false;
  }//end dispatchKeyEvent
}//end class AlternateDispatcherA
//=============================================//

class AlternateDispatcherB
                   implements KeyEventDispatcher{
  JTextField fieldB;
  JTextField fieldC;
  KeyboardFocusManager manager;

  //Constructor
  AlternateDispatcherB(
                   JTextField fieldB,
                   JTextField fieldC,
                   KeyboardFocusManager manager){
    this.fieldB = fieldB;
    this.fieldC = fieldC;
    this.manager = manager;
  }//end constructor

  public boolean dispatchKeyEvent(KeyEvent e){
    if(e.getSource() == fieldB){
      manager.redispatchEvent(fieldC,e);
    }//end if
    return false;
  }//end dispatchKeyEvent
}//end class AlternateDispatcherB
//=============================================//

class PostProcessor
                implements KeyEventPostProcessor{

  public boolean postProcessKeyEvent(KeyEvent e){
    System.out.println(
               e.getKeyChar() + " " +
                        getEventType(e.getID()));
    return true;
  }//end postProcessKeyEvent
//---------------------------------------------//

String getEventType(int ID){
  if(ID == KeyEvent.KEY_PRESSED){
    return "keyPressed";
  }else if(ID == KeyEvent.KEY_RELEASED){
    return "keyReleased";
  }else if(ID == KeyEvent.KEY_TYPED){
    return "keyTyped";
  }else{
    return "Unknown event type";
  }//end else
}//end getEventType

}//end class PostProcessor